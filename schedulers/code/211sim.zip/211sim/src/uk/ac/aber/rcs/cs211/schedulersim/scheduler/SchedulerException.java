package uk.ac.aber.rcs.cs211.schedulersim.scheduler;

public class SchedulerException extends Exception {

	static final long serialVersionUID = 0;
	
	public SchedulerException() {
		super();
	}
	
	public SchedulerException(String text) {
		super(text);
	}
	
}
